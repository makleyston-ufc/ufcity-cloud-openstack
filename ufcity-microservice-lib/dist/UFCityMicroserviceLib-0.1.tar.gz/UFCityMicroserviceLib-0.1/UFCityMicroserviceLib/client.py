from UFCityMicroserviceLib import somar

result = somar(3, 5)

print(f"O resultado é {result}")

