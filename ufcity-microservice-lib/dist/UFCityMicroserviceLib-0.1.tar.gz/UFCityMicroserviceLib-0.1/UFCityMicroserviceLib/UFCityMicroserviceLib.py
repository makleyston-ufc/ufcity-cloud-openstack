def somar(a, b):
    return a + b