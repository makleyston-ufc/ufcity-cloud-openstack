from setuptools import setup

setup(
    name='UFCityMicroserviceLib',
    version='0.1',
    packages=['UFCityMicroserviceLib'],
    install_requires=[],
)
